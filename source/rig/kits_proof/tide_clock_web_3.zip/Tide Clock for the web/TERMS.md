# Tide Clock — terms of use for the public demo

Copyright (c) 2026 Ada Example. All rights reserved.

## What this is

This is a demonstration of Tide Clock, an application written and designed
by Ada Example. It is published so that it can be seen and tried. It is not
published for reuse.

## What you may do

Open it, read it, try it, and run it in your own browser for your own use.
Link to it. Write about it. Quote briefly from it with attribution, as you would
quote any published work.

## What you may not do

Without prior express written permission from the author, you may not:

- copy, download for redistribution, mirror or rehost this application, in whole
  or in part
- adapt, modify, translate or build upon it
- extract any part of it, including its text, the interface prose, the design or
  the icons, for use in any other work
- reverse engineer it or reuse any component of it
- make any commercial use of it or anything derived from it
- use it, or any part of it, to train, fine tune or evaluate a machine learning
  system

The written work carried inside the application is protected independently of the
code.

## Automated collection

Automated crawling, scraping or bulk downloading of this application for dataset
construction or model training is not permitted. This is stated here so that it
cannot be said no notice was given.

## Your work stays yours

Anything you write in the demo is yours. Keep your own copy of anything that
matters to you.

## No warranty

Provided as is, without warranty of any kind. The author is not liable for any
loss arising from its use.

## Marking

Every published build carries a build marker, so a copy in circulation can be
traced to the build it came from.

## Permission

Requests for any use not permitted above are welcome and are answered in writing.
Ask the author.

## Nothing here removes your legal rights

Nothing in these terms limits any right you have that cannot be limited by
agreement under the law that applies to you.
