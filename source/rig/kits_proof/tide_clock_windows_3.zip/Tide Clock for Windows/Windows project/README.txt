TIDE CLOCK  |  Copyright (c) 2026 Ada Example. All rights reserved.
NO LICENCE IS GRANTED. No copying, adaptation, redistribution, reverse
engineering or commercial use without the author's written permission.
See LICENCE.txt. Every distributed copy carries a build marker.
--------------------------------------------------------------------------

TIDE CLOCK ON A WINDOWS PC
==========================

Build 3 (3), 2026-11-17. Made by Fabrica, 17 November 2026.

On Windows, Tide Clock is one standalone program. You install it once
with its installer. Then it opens in its own window from the Start menu,
like any other program. It needs nothing else on your PC: no Python, and
no browser.

The installer is made for you on GitHub, or on this PC (Part 4). This
package holds what both need to make it.

Tide Clock draws its own window with Microsoft's WebView2 component,
which comes with Windows 10 and 11. That is not a browser window.

WHAT IS IN THIS PACKAGE
  READ ME FIRST.txt               This guide.
  Windows project\                Everything needed to build the program
                                  and its installer, on GitHub or on
                                  this PC (Part 4).
  GITHUB_WORKFLOW_paste_this.txt  The build recipe, as a visible file you can
                                  copy from (Part 1, Step 3).
  LICENCE.txt


PART 1. HAVE GITHUB MAKE THE INSTALLER
--------------------------------------

Step 1. Make a repository.
  Sign in at github.com. Click the "+" at the top right, then
  "New repository". Name it, for example tide-clock-windows. Choose
  Private. Do NOT tick "Add a README file". Click "Create repository".
  (You may use the repository you already have for this app instead.)

Step 2. Upload the project.
  On the new repository's page click "uploading an existing file".
  Open the folder "Windows project" from this package, select EVERYTHING
  INSIDE IT (Ctrl+A), and drag it onto the page. You should see
  tide_clock.spec, tide_clock.iss, tide_clock_app.py and
  tide_clock.html in the list. Wait until every file has finished
  uploading, then click "Commit changes".
  If your repository still holds the two .bat files from an older
  package, they are no longer used. You may leave them or delete them.

Step 3. Add the build recipe. THIS STEP MATTERS.
  The recipe lives in a folder called .github, which is easily left
  behind when uploading (a Mac always hides it). Without it GitHub
  never builds anything.
    a. On the repository page click "Add file", then "Create new file".
    b. In the name box type exactly:
           .github/workflows/build-windows-app.yml
       (GitHub turns each "/" into a folder as you type.)
    c. Open GITHUB_WORKFLOW_paste_this.txt from this package, select all
       of it, copy it, and paste it into the large box on GitHub.
    d. Click "Commit changes", then "Commit changes" again.
  If GitHub says the file already exists, it uploaded in Step 2. If you
  are updating a repository that had an OLDER recipe, open the file
  there, click the pencil, replace everything with the new text, and
  commit.

Step 4. Wait for the build.
  Click the "Actions" tab. "Build Tide Clock for Windows" runs for about
  five to ten minutes; a green tick means it worked.
  On GitHub's own Windows computer it:
    - builds the program as a program folder, with PyInstaller's
      standard starter and its version details;
    - checks that the app inside is byte for byte the file tide_clock.html
      you uploaded;
    - opens it, waits until its page says it is ready (at most two
      minutes), and notes how long that took. It keeps a photograph of
      it under "Artifacts", and tries a second start, which should only
      bring the open window to the front (a warning if it does not);
    - makes the installer, then installs and uninstalls it silently,
      also over the open program and while it is open;
    - scans the installer and the program with Microsoft Defender,
      with the newest definitions. It only scans: it changes nothing in
      Defender. If Defender names a threat, the run stops with a red
      cross and NOTHING is published.
  If nothing has started after a minute: click "Build Tide Clock for
  Windows" on the left, then "Run workflow", then the green "Run workflow".

Step 5. Get the installer.
  On the repository's main page, on the right, click "Releases", then
  the release named "Tide Clock ... for Windows (build ...)". Its name
  gives the version and the build number. Under "Assets", the installer
  is the file whose name ends in "-Setup.exe". It is the only file to
  download.
  The release notes say what Microsoft Defender found on GitHub's
  computer (nothing, or "NOT MEASURED" if it could not scan there),
  which starter the program was built with, how long the program took
  to open there, and the installer's SHA-256 fingerprint.

COST: for a private repository GitHub counts each minute on its Windows
computers as more than one minute of your monthly allowance (twice, as
far as I know). One build takes about five to ten minutes. Please check
GitHub's current figures on its billing pages.


PART 2. INSTALL TIDE CLOCK
--------------------------

1. If you already use Tide Clock on this PC, export a backup from it
   first and keep the file (with the app's own backup or Export, where it
   has one). The installer also copies the folder that holds your
   work before it changes anything.
2. Download the installer from the Releases page (Part 1, Step 5).
   Microsoft Edge may warn that the file is not commonly downloaded.
   That warning is about reputation: the file is new, few people have
   downloaded it yet, and it is not signed with a paid certificate. It
   is not about anything found inside it. Do NOT click "Delete":
     a. Point at the download and click the three dots beside it.
     b. Click "Keep".
     c. Click "Show More", then "Keep anyway".
   If Edge says instead that the file may be unwanted or unsafe, that
   is Microsoft's judgement of the file itself. Please follow IF WINDOWS
   REMOVES IT, below, before you keep it.
3. Open the installer. The first time, Windows may show "Windows
   protected your PC".
     a. Click the small link under the message (as far as I know it
        says "More info").
     b. Click "Run anyway".
   This too is about reputation (CODE SIGNING, below). You see it once
   for each new installer.
4. The installer needs no administrator password. It installs
   Tide Clock for you only, into %LOCALAPPDATA%\Programs\Tide Clock,
   puts it in the Start menu, and on the Desktop if you leave that box
   ticked. Click Install. At the end it offers to open Tide Clock.
5. If the OLD single file Tide Clock.exe, or Tide-Clock-Windows.zip, is still
   on your Desktop or in Downloads, delete it. Your work is not inside
   it.

The installed program is a folder: Tide Clock.exe and, beside it, a
folder named _internal. Keep them together, and open Tide Clock from
the Start menu or the Desktop shortcut.

To remove Tide Clock: Settings, Apps, Installed apps, Tide Clock,
Uninstall. Your work stays in %LOCALAPPDATA%\TideClock. If Tide Clock
is open, the uninstaller first closes it, the way its own close button
does.

WebView2 is on nearly every Windows 10 and 11 PC. If it is missing, the
installer says so on one page, with a button to Microsoft's free
download, and carries on. Install "Microsoft Edge WebView2 Runtime" from
that page, then open Tide Clock. Until then it cannot draw its own
window; it opens in your browser instead, and says so.


IF WINDOWS REMOVES IT, OR CALLS IT MALWARE OR UNWANTED
------------------------------------------------------
Of Windows' guards, only Microsoft Defender Antivirus (part of Windows
Security) removes a file. Edge's warnings, "Windows protected your PC"
and Smart App Control warn or block, but do not delete.

Each time Defender removes something, Windows keeps a note. The note
says what Windows thought it found, and which file. With that, the
right thing can be fixed. Windows keeps these notes for a short time
only (about two weeks, as far as I know), so it helps to look soon.

Find the exact name:
  1. Click Start, type Windows Security, and open it.
  2. Choose "Virus & threat protection".
  3. Under "Current threats", choose "Protection history".
  4. Find the entry from the day Tide Clock disappeared, and click it
     to open it. If Windows asks for permission, choose Yes.
  5. Write down, or photograph, three things:
       - the name of the threat (it may begin with a word such as
         "Trojan" or "PUA", and it may end with "!" and two letters);
       - the file it names, with its folder (a line beginning C:\);
       - what Windows did, and the date.
  6. Please do not press "Allow" or "Restore" yet. Nothing changes
     until you choose, and we can decide together once the name is
     known.
  7. Go back to "Virus & threat protection", choose "Protection
     updates", and note the "Security intelligence" version (as far as
     I know it is shown there).
  8. Pass the photo or the notes on. That is all.

If the entry has gone, Event Viewer usually keeps the same facts for
longer (as far as I know):
  1. Press the Windows key and R together, type eventvwr.msc, and press
     OK.
  2. On the left, open "Applications and Services Logs", then
     "Microsoft", "Windows", "Windows Defender", "Operational".
  3. Look for events numbered 1116 and 1117 on the day Tide Clock
     disappeared, and click one.
  4. Note or photograph "Name" (the threat), "Path" (the file) and
     "Signature Version" (the definitions).

If neither shows anything, the stop may have come from SmartScreen or
Smart App Control instead. Next time, note the words on the screen, or
take a picture of the screen with the Windows key, Shift and S together.

What the name says. Its first word gives the kind of judgement:
"Trojan" and similar words mean Defender judged the file harmful; "PUA"
or "App" means a "potentially unwanted app". A name ending in "!ml" is
common for a new program. Microsoft does not say what "!ml" means; it is
widely read as "machine learning", a guess that the file looks like
harmful ones, not a match with any known harmful program.

Report the mistake to Microsoft (free). Microsoft's page for this is
"Submit a file for malware analysis":
    https://www.microsoft.com/en-us/wdsi/filesubmission
  1. Open that page. For "Submit file as a", choose "Software
     developer".
  2. Sign in with a Microsoft account. That is how you see Microsoft's
     answer.
  3. Choose the product that removed it, for example "Microsoft
     Defender Antivirus (Windows 11)".
  4. Choose the file: the exact file Protection history named (for
     example the installer, whose name ends in "-Setup.exe"). The page
     takes files up to 50 MB.
  5. For "What do you believe this file is?", choose "Incorrectly
     detected as malware/malicious". If the name began with "PUA",
     choose "Incorrectly detected as PUA (potentially unwanted
     application)" instead.
  6. "Detection name": copy the name exactly from Protection history.
  7. "Definition version": the Security intelligence version you noted.
  8. "Additional information", in English: say that this is your own
     offline desktop program, built with PyInstaller and Inno Setup on
     GitHub from your own repository, and paste the SHA-256 given in the
     release notes.
  9. Send it, and wait for Microsoft's answer. When Microsoft agrees, it
     changes its definitions. Then, in Windows Security, choose "Virus &
     threat protection", "Protection updates", "Check for updates", and
     download and install Tide Clock again.

Please do not switch Defender off, and do not exclude whole folders such
as Downloads.

If the message names Smart App Control, there is no "Run anyway". Smart
App Control (Windows 11) blocks an unsigned program unless Microsoft's
cloud already trusts it. It can be switched off in Windows Security,
"App & browser control", "Smart App Control settings". Microsoft's own
pages disagree on whether it can be switched on again later without
resetting Windows, so please think it over first.


WHY WINDOWS MAY REMOVE IT
-------------------------
A program new to Windows has no reputation yet, and this one is not signed
(see below). The steps above find which file Windows removed and the name
it gave. What helps:
  - The program is built with PyInstaller's standard starter, which
    Windows has seen on many PCs, never a new one made for each build.
  - GitHub's scan is good evidence, not a guarantee. Your PC can also
    ask Microsoft's cloud, and may send it a new program for a closer
    look. The cloud may judge differently. If it does, the steps above
    say what to do.

CODE SIGNING: THE ONLY CURE FOR THE WARNINGS, AND IT COSTS MONEY
----------------------------------------------------------------
Tide Clock is not signed today. Code signing attaches
your verified name to every build. Windows then names you as the
publisher, Smart App Control lets the program run, and SmartScreen's
trust carries over from one build to the next, so the warnings fade as
people install it. It does not promise that Defender never objects; for
that, the report above is the cure.

Signing needs either Microsoft's own signing service (a monthly fee; as
far as I know open to individual developers only in the United States
and Canada) or a code-signing certificate from a certificate authority (a
yearly fee, with the key kept on a hardware token or in the authority's
cloud). Please check the current prices and conditions with the
providers. The free signing programmes I know of are for open-source
projects only, and Tide Clock is not open source. Once you have a
signing account, the GitHub build can be extended to sign every build
automatically.


PART 3. UPDATING THE PROGRAM LATER
----------------------------------

  1. On GitHub, open your repository. Click "Add file", then "Upload
     files", drop in EVERYTHING inside the new package's "Windows
     project" folder (the app, its icon, BUILD_INFO.txt and the rest;
     the files replace the old ones), and commit.
  2. GitHub builds again by itself (Part 1, Steps 4 and 5).
  3. Download the new installer and open it. It replaces the program and
     keeps your work.


PART 4. MAKING IT ON THIS PC INSTEAD (optional)
-----------------------------------------------

"Build Tide Clock (Windows).bat", inside "Windows project", makes the
same program and the same installer on this PC. It needs, once:
  - Python 3.12, from www.python.org/downloads (in its installer, tick
    "Add python.exe to PATH");
  - the internet, to fetch the build tools (the same versions GitHub's
    build uses);
  - Inno Setup 6, from jrsoftware.org, for the installer. Without it the
    build still makes the program folder, which runs as it is.
Double-click the .bat file. If Windows SmartScreen stops it, choose More
info, then Run anyway. A window shows each step; the first build takes
several minutes. When it ends:
  - the installer, whose name ends in -Setup.exe, is in this package's
    top folder, beside READ ME FIRST.txt; open it to install Tide Clock;
  - the program folder is "Windows project\dist\Tide Clock".
Each run writes build_log.txt in "Windows project". If a build fails, the
window says why, and the last lines of that file name the cause.


IF THE BUILD FAILS
------------------

A red cross within a few seconds, with no steps listed:
  GitHub refused to start the build. This is about the GitHub account,
  not the app. Open the failed run and read the notice near the top.
  The usual reasons are that the account has used its monthly free
  minutes, or a spending limit or payment problem in the billing
  settings (github.com/settings/billing). Fix what the notice names,
  then click "Re-run all jobs".

A red cross after some minutes, with steps listed:
  Click the step with the red cross. "If the build failed, show why"
  prints the last 80 lines of the build log; they name the cause.

A red cross at "Scan with Microsoft Defender":
  Defender named a threat, so nothing was published. The step's text,
  and defender-report.txt under "Artifacts", name the file and the
  threat. Report it to Microsoft as described above, then run the build
  again once Microsoft has answered. Please do not remove the scan.

A yellow warning that Defender was "not measured":
  GitHub's computer could not run the scan this time. The installer was
  published, and its release notes say "NOT MEASURED".

A red cross at "Put the installer on the Releases page":
  First click "Re-run failed jobs". GitHub's upload service sometimes
  fails (for example "HTTP 500"), and the recipe already tries four
  times. Only if the message says 403 or "Resource not accessible by
  integration": Settings, Actions, General, Workflow permissions: choose
  "Read and write permissions", Save, then "Re-run all jobs".

"tide_clock.spec not found" or "tide_clock.iss is missing":
  The project was not uploaded, or only partly. Upload the CONTENTS of
  "Windows project" again (Part 1, Step 2).


ABOUT THE PROGRAM
-----------------
  - It runs entirely from the copy of tide_clock.html inside it and works with
    no connection. Your work is kept in this folder on the PC:
        %LOCALAPPDATA%\TideClock
    and the installer copies it to %LOCALAPPDATA%\TideClock\backups
    before each installation, keeping the three newest copies.
  - Only one copy opens at a time. If you click its icon again while it
    is open, or still opening, its window comes to the front. No second
    copy starts.
  - The window opens in the colour of the page, light or dark, as you
    last used it.
  - Each build measures how long the program takes to open on GitHub's
    Windows computer. The release notes give the times: window shown,
    page loaded, page ready. That computer has no graphics chip, so a PC
    is usually quicker.
  - It always opens in its own window. If a run ever ends badly (for
    example the PC loses power while it is open), the next run switches
    to safe graphics on that PC: a little less smooth, and steadier. A
    small note, tide_clock_safe_graphics.txt in
    %LOCALAPPDATA%\TideClock\storage, says so. To try full graphics
    again, close Tide Clock and delete that note.
  - It writes a short record of each start to tide_clock_crash.log, in
    %LOCALAPPDATA%\TideClock. If something goes wrong, that file says
    what happened.
